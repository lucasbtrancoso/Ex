package com.example.prova;

public class Paciente {
    String nome;
    int idade;
    String mortalidade;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getMortalidade() {
        return mortalidade;
    }

    public void setMortalidade(String mortalidade) {
        this.mortalidade = mortalidade;
    }
}
